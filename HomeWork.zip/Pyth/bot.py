import telebot
from bot_logic import gen_pass
import os
import random
token = "8429190681:AAFfI6baiO3n-ZUyEkPS4ZKYggUmLriOKtc"
bot = telebot.TeleBot(token)
    
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Привет! Я твой Telegram бот. Напиши что-нибудь!")
@bot.message_handler(commands=['check_me'])
def send_hello(message):
    bot.reply_to(message, "Вы человек? /yes или /no")
@bot.message_handler(commands=['yes'])
def send_hello(message):
    bot.reply_to(message, "Отлично, вы самая высшая форма жизни на этой планете.")
@bot.message_handler(commands=['no'])
def send_hello(message):
    bot.reply_to(message, "Вам не доступны человеческие блага.")
@bot.message_handler(commands=['hello'])
def send_hello(message):
    bot.reply_to(message, "Привет! Как дела?")
@bot.message_handler(commands=['bye'])
def send_bye(message):
    bot.reply_to(message, "Пока! Удачи!")
@bot.message_handler(commands=['password'])
def send_password(message):
    bot.reply_to(message, gen_pass(10))

@bot.message_handler(commands=['mem'])
def send_mem(message):
    
    img_name = random.choice(os.listdir('images'))
    with open(f'images/{img_name}', 'rb') as f:  
            bot.send_photo(message.chat.id, f)  
def send_mem(message):
    with open('images/meme1.jpeg', 'rb') as f:  
        bot.send_photo(message.chat.id, f)  
print(os.listdir('images'))
def flip_coin():
    flip = random.randint(0, 1)
    if flip == 0:
        return "Эщкере, выпал орёл"
    else:
        return "Эщкере, выпала решка"
@bot.message_handler(func=lambda message: True)
def echo_all(message):
    if message.text == "Здравствуй":
        bot.reply_to(message, "Рот закрой")
    elif message.text == "Орёл, или решка?":
        result = flip_coin()
        bot.send_message(message.chat.id, result)
@bot.message_handler(func=lambda message: True)
def echo_all(message):
    if message.text == "Орёл, или решка?":
        result = flip_coin()
        bot.send_message(message.chat.id, result)

bot.polling()